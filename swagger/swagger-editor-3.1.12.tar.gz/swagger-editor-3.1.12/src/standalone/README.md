This is the Editor's Standalone preset - it adds some features used by [editor.swagger.io](http://editor.swagger.io):

- Topbar with Swagger branding
- URL/File import
- YAML conversion trigger
- JSON/YAML export
